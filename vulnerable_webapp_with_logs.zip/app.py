from flask import Flask, request, render_template, redirect, make_response, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)

LOG_FILE = 'log.txt'

# Create a simple user table if not exists
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)''')
    c.execute("INSERT INTO users (username, password) VALUES ('admin', 'password123')")
    conn.commit()
    conn.close()

# Append login log to file
def log_login(username, ip, cookie):
    with open(LOG_FILE, 'a') as f:
        f.write(f"{datetime.now()} | Username: {username} | IP: {ip} | Session: {cookie}\n")

@app.route('/', methods=['GET', 'POST'])
def login():
    ip = request.remote_addr
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
        c.execute(query)
        user = c.fetchone()
        conn.close()
        if user:
            session_val = f'{username}|{ip}|{datetime.now()}'
            resp = make_response(redirect('/admin'))
            resp.set_cookie('session', session_val)
            log_login(username, ip, session_val)
            return resp
        return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/admin')
def admin():
    session = request.cookies.get('session')
    if not session or not session.startswith('admin'):
        return "Access Denied", 403
    ip = request.remote_addr
    try:
        with open(LOG_FILE, 'r') as f:
            logs = f.readlines()
    except FileNotFoundError:
        logs = []
    return render_template('admin.html', user_session=session, ip=ip, logs=logs)

if __name__ == '__main__':
    init_db()
    app.run(debug=False)